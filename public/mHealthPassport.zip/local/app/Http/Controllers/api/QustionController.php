<?php

namespace App\Http\Controllers;

use App\qustion;
use Illuminate\Http\Request;

class QustionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\qustion  $qustion
     * @return \Illuminate\Http\Response
     */
    public function show(qustion $qustion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\qustion  $qustion
     * @return \Illuminate\Http\Response
     */
    public function edit(qustion $qustion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\qustion  $qustion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, qustion $qustion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\qustion  $qustion
     * @return \Illuminate\Http\Response
     */
    public function destroy(qustion $qustion)
    {
        //
    }
}
